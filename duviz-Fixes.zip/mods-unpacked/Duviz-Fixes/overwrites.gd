extends Node

var scripts: Array
const SCRIPTS := [
	"Flesh_Rat.gd",
	"Settings.gd",
]

var mod_scripts_folder := "res://mods-unpacked/Duviz-Fixes/overwrites/Scripts"
var vanilla_scripts_folder := "res://Scripts"

func _init():
	for script in SCRIPTS:
		var script_overwrite := load(mod_scripts_folder.plus_file(script))
		script_overwrite.take_over_path(vanilla_scripts_folder.plus_file(script))
		scripts.append(script_overwrite)
