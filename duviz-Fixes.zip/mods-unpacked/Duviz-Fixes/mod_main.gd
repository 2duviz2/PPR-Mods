extends Node


const AUTHORNAME_MODNAME_DIR := "Duviz-Fixes"
const AUTHORNAME_MODNAME_LOG_NAME := "Duviz-Fixes:Main"


func _ready() -> void:
	pass


func _process(delta : float) -> void:
	pass
