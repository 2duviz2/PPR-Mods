extends TabContainer

onready var control_list: ItemList = $Controls / HBoxContainer / ItemList
onready var auto_font_size_check: CheckBox = $General / GridContainer / VBoxContainer2 / CheckBox
var input_selected: InputEvent = null
var auto_font_size = false # literally not used in this version
onready var resolution_list: ItemList = $General / GridContainer / VBoxContainer / ItemList
var resolutions: Array = [Vector2(2560, 1440), 
							Vector2(1920, 1080), 
							Vector2(1920, 1200), 
							Vector2(1680, 1050), 
							Vector2(1440, 900), 
							Vector2(1366, 768), 
							Vector2(1280, 800), 
							Vector2(1280, 720), 
							Vector2(1600, 1200), 
							Vector2(1024, 768), 
							Vector2(800, 600), 
							Vector2(640, 480)]

func _ready():
	var i = 0
	for a in InputMap.get_actions():
			if a.find("ui_") != - 1:
						continue
			var e = InputMap.get_action_list(a)[0]
			match e.get_class():
				"InputEventKey":
					control_list.add_item(a + " " + OS.get_scancode_string(e.scancode))
					control_list.set_item_metadata(i, a)
					control_list.set_item_custom_fg_color(i, Color(0, 1, 0))
					i += 1
				"InputEventMouseButton":
					control_list.add_item(a + " " + str("{", e.button_index, "}").format({1: "MOUSE_L", 2: "MOUSE_R", 3: "MOUSE_M", 4: "SCROLL_UP", 5: "SCROLL_DOWN", 6: "SCROLL_LEFT", 7: "SCROLL_RIGHT", 8: "MOUSE_X_1", 9: "MOUSE_X_2"}))
					control_list.set_item_metadata(i, a)
					control_list.set_item_custom_fg_color(i, Color(0, 1, 1))
					i += 1
	i = 0
	for r in resolutions:
		resolution_list.add_item(str(r.x, "x", r.y))
		resolution_list.set_item_metadata(i, r)
		i += 1
	$General / GridContainer / VBoxContainer2 / SpinBox.value = Dataset.font_size
	$General / GridContainer / VBoxContainer2 / Sens_Slider.value = Global.mouse_sens
	$General / GridContainer / VBoxContainer2 / Mech_Sens_Slider.value = Global.mech_mouse_sens
	$General / GridContainer / VBoxContainer2 / Mech_Fov_Slider.value = Global.mech_fov
	$General / GridContainer / VBoxContainer2 / HSlider.value = Global.fov
	$General / GridContainer / VBoxContainer2 / FPS_Label.pressed = Global.limit_fps
	$General / GridContainer / VBoxContainer2 / FPS_spinbox.value = Global.fps_limit
	$General / GridContainer / VBoxContainer2 / Invert_Y.pressed = Global.invert_y
	$General / GridContainer / VBoxContainer2 / Legacy.pressed = Global.legacy_aim
	
	auto_font_size_check.hide()
	_on_Font_value_changed(Dataset.font_size)


func _input(event):
	if event.get_class() == "InputEventMouseButton":
		if not event.pressed:
			return
	if event.get_class() != "InputEventMouseMotion":
		input_selected = event
		$Key_Popup.hide()


func _on_ItemList_item_activated(index):
	var a = control_list.get_item_metadata(index)
	var e = InputMap.get_action_list(a)[0]
	$Key_Popup.popup_centered_minsize(Vector2(100, 100))
	while ($Key_Popup.visible):
		yield(get_tree(), "idle_frame")
	InputMap.action_erase_events(a)
	InputMap.action_add_event(a, input_selected)
	if input_selected.get_class() == "InputEventMouseButton":
		var mbutton = str("{", input_selected.button_index, "}").format({1: "MOUSE_L", 2: "MOUSE_R", 3: "MOUSE_M", 4: "SCROLL_UP", 5: "SCROLL_DOWN", 6: "SCROLL_LEFT", 7: "SCROLL_RIGHT", 8: "MOUSE_X_1", 9: "MOUSE_X_2"})
		control_list.set_item_text(index, a + " " + mbutton)
	else:
		control_list.set_item_text(index, a + " " + OS.get_scancode_string(input_selected.scancode))


func _on_Resolution_item_activated(index):
	if resolution_list.get_item_metadata(index).y >= OS.get_screen_size().y:
		OS.window_borderless = true
	else:
		OS.window_borderless = false
	Dataset.resolution = resolution_list.get_item_metadata(index)
	OS.window_size = resolution_list.get_item_metadata(index)
	
	get_viewport().size = resolution_list.get_item_metadata(index)
	OS.center_window()


func _on_HSlider_value_changed(value):
	$General / GridContainer / VBoxContainer2 / Fov_Label.text = "FOV: " + str(value)
	Global.fov = value


func _on_Font_value_changed(value):
	value = int(value)
	Dataset.font_size = clamp(value, 8, 128)
	Dataset.default_font.size = value
	Dataset.intro_font.size = int(Dataset.font_size * 2)
	Dataset.small_font.size = int(Dataset.font_size)
	Global.font_size = value
	$General / GridContainer / VBoxContainer2 / SpinBox.value = get_theme_default_font().size


func _on_FullScreen_toggled(button_pressed):
	var v_size = Dataset.resolution
	
	OS.window_size = v_size
	OS.window_fullscreen = button_pressed
	get_viewport().size = Dataset.resolution
	if button_pressed:
		get_tree().set_screen_stretch(SceneTree.STRETCH_MODE_VIEWPORT, SceneTree.STRETCH_ASPECT_IGNORE, Dataset.resolution)
	else:
		get_tree().set_screen_stretch(SceneTree.STRETCH_MODE_DISABLED, SceneTree.STRETCH_ASPECT_IGNORE, Dataset.resolution)
	
	


func _on_CustomResButton_pressed():
	var res = Vector2($General / GridContainer / VBoxContainer / Custom / LineEdit.value, $General / GridContainer / VBoxContainer / Custom / LineEdit2.value)
	if res.y >= OS.get_screen_size().y:
		OS.window_borderless = true

	else:
		OS.window_borderless = false
	Dataset.resolution = res
	OS.window_size = res
	Dataset.save_settings("default")
	
	get_viewport().size = res
	OS.center_window()


func _on_Sens_Slider_value_changed(value):
	$General / GridContainer / VBoxContainer2 / Sens_Label.text = "Mouse Sensitivity (Infantry):\n" + str(value)
	if $General / GridContainer / VBoxContainer2 / Lock_Sensitivity.pressed:
		$General / GridContainer / VBoxContainer2 / Mech_Sens_Slider.value = value
		Global.mech_mouse_sens = value
	Global.mouse_sens = value


func _on_Mech_Sens_Slider_value_changed(value):
	if $General / GridContainer / VBoxContainer2 / Lock_Sensitivity.pressed:
		$General / GridContainer / VBoxContainer2 / Sens_Slider.value = value
		Global.mouse_sens = value
	$General / GridContainer / VBoxContainer2 / Sens_Label2.text = "Mouse Sensitivity (Mech):\n" + str(value)
	Global.mech_mouse_sens = value


func _on_Mech_Fov_Slider_value_changed(value):
	$General / GridContainer / VBoxContainer2 / Mech_Fov_Label.text = "Mech FOV: " + str(value)
	Global.mech_fov = value


func _on_Draw_Slider_value_changed(value):
	$General / GridContainer / VBoxContainer2 / Draw_Label.text = "Draw Distance: " + str(value, "m")
	Global.draw_distance = value


func _on_Save_Settings_Button_pressed():
	Dataset.save_settings("default")


func _on_Autofont_pressed(value):
	auto_font_size = value
	


func _on_FPS_Label_toggled(button_pressed):
	Global.limit_fps = button_pressed
	if button_pressed:
		Engine.target_fps = $General / GridContainer / VBoxContainer2 / FPS_spinbox.value
		
	else:
		Engine.target_fps = 0


func _on_FPS_spinbox_value_changed(value):
	if $General / GridContainer / VBoxContainer2 / FPS_Label.pressed:
		Engine.target_fps = value
		Global.fps_limit = value
	else:
		Engine.target_fps = 0


func _on_Invert_Y_toggled(button_pressed):
	Global.invert_y = button_pressed


func _on_Legacy_toggled(button_pressed):
	Global.legacy_aim = button_pressed


func _on_Doubletap_toggled(button_pressed):
	Global.double_tap = button_pressed
