extends "res://Scripts/Vehicle.gd"





export var sight_distance = 20
export var attack_distance = 1
export var melee_damage = 10
export var toxicity_damage = 50
export var rad_damage = 0
export var right_angles = false
var attack_timer = 0
var sight = false
export var attack_frequency = 5
var reaction_time = 2.0
var ray: RayCast
var player_spotted = false
var dir = Vector3.FORWARD
var dist = Vector3.ZERO
var t = 0
onready var weapon = get_node_or_null("Weapons/Weapon")

func _ready():
	ray = RayCast.new()
	if get_node_or_null("Timer") != null:
		$Timer.connect("timeout", self, "attack")
	add_child(ray)
	ray.global_transform.origin = global_transform.origin + Vector3.UP * 0.25
	ray.cast_to = Vector3(0, 0, - sight_distance)
	ray.enabled = true
	ray.set_collision_mask_bit(0, 1)
	ray.set_collision_mask_bit(1, 1)
	
	rotation.x = 0
	rotation.z = 0
	if weapon:
		weapon.weapon_owner = self
	yield(get_tree(), "idle_frame")
	look_at(Global.target.global_transform.origin, Vector3.UP)


func _physics_process(delta):
	t += 1
	if dead:
		if not is_on_floor():
			velocity.y -= gravity * delta
		velocity.x *= 0.9
		velocity.z *= 0.9
		velocity = move_and_slide(velocity, Vector3.UP, false)
		return
	
	dist = global_transform.origin.distance_to(Global.target.global_transform.origin)
	
	if dist >= sight_distance and not player_spotted:
		return
	
	if t % 50 == 0:
		ray.look_at(Global.target.pos, Vector3.UP)
		sight = false
		if ray.is_colliding():
				if ray.get_collider() == Global.target:
					player_spotted = true
					sight = true
	
	
	if not player_spotted:
		return
	
	
	dir = - ((global_transform.origin - Global.target.global_transform.origin) * Vector3(1, 0, 1)).normalized()
	attack_timer += delta
	
	if hostile and player_spotted:
		look_at(Global.target.global_transform.origin, Vector3.UP)
		if speed < 0:
			rotate_y(deg2rad(180))
		if right_angles:
			rotation_degrees.y = stepify(rotation_degrees.y, 90)
	
	rotation.x = 0
	rotation.z = 0
	
	if dist < attack_distance and hostile and player_spotted:
		reaction_time -= delta
		reaction_time = clamp(reaction_time, 0, 2.0)
		if weapon:
			weapon.look_at(Global.target.pos, Vector3.UP)
		else:
			reaction_time = 0
		if attack_timer >= attack_frequency and reaction_time == 0:
			if get_node_or_null("Timer"):
				$Timer.start()
			else:
				attack()
			
			attack_timer = 0
			if melee_damage > 0:
				if $FLESHRAT / AnimationPlayer.has_animation("Attack"):
					$FLESHRAT / AnimationPlayer.play("Attack")
				$Attack_Sound.play()
	elif ((dist < sight_distance or speed < 0) and player_spotted) and hostile:
		if speed < 0:
			velocity -= dir * top_speed * delta
		else:
			velocity += dir * top_speed * delta
		$FLESHRAT / AnimationPlayer.play("Run")
		reaction_time += delta
		reaction_time = clamp(reaction_time, 0, 2.0)
	else:
		$FLESHRAT / AnimationPlayer.play("Idle")
		reaction_time += delta
		reaction_time = clamp(reaction_time, 0, 2.0)
	if not is_on_floor():
		velocity.y -= gravity * delta
	velocity.x *= 0.9
	velocity.z *= 0.9
	velocity = move_and_slide(velocity, Vector3.UP, false)
	attack_timer += delta
	attack_timer = clamp(attack_timer, 0, attack_frequency)


func attack():
	if weapon:
		if weapon.mag_ammo > 0:
			weapon.shoot(Vector3.ZERO, self)
		return
	if dist > attack_distance or not sight:
		return
	if dead:
		return

	
	Global.target.velocity += - ((global_transform.origin - Global.target.global_transform.origin)).normalized() * melee_damage
	Global.target.damage(dir * 100, melee_damage, 0.0, toxicity_damage, 0, rad_damage)
	if rad_damage > 0:
		Global.target.emit_signal("rad_changed", Global.target.radiation)
