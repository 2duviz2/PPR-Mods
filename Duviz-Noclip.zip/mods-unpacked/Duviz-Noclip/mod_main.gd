extends Node


const AUTHORNAME_MODNAME_DIR := "Duviz-Noclip"
const AUTHORNAME_MODNAME_LOG_NAME := "Duviz-Noclip:Main"

var mod_dir_path := ""


func _init() -> void:
	mod_dir_path = ModLoaderMod.get_unpacked_dir().plus_file(AUTHORNAME_MODNAME_DIR)


func _process(delta : float) -> void:
	var player_inf = Global.player_inf
	if player_inf:
		if Input.is_action_just_pressed("NOCLIP") and player_inf.input_available and not Global.debug:
			player_inf.noclip = not player_inf.noclip
			player_inf.noclip_speed = 10
			player_inf.set_collision_mask_bit(0, not player_inf.noclip)
			player_inf.set_collision_layer_bit(1, not player_inf.noclip)
